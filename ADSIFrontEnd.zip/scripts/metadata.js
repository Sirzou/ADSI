define(function(){
    return {
        pageGroups: [{"id":1,"name":"Default group","pages":[{"id":"30e3289d-daff-f796-185d-62642386d849","name":"Page 1"},{"id":"c09aad4b-d93c-7e50-f5ba-690158dc612a","name":"Page 2"},{"id":"7a52046d-106e-8e05-ce4f-3797d3dba0de","name":"Page 3"},{"id":"f3412610-b968-b286-681b-693165388e7a","name":"Page 4"},{"id":"5996875a-b83b-ae87-7135-51d6d62cc4f3","name":"Page 5"},{"id":"280fe33d-dc06-bee7-1dea-f3f9ccdd98ad","name":"Page 6"},{"id":"3e2c7d3d-5aaf-cbba-9c45-bbc5ab0e1e4a","name":"Page 7"},{"id":"e33b02b3-bbf5-9889-4af8-f046bdc5bf4b","name":"Page 8"},{"id":"fa1d5041-6e9e-77bb-547b-6400ed374a0c","name":"Page 9"},{"id":"abc00041-cc2d-381e-1712-b909da7c2964","name":"Page 10"},{"id":"17f5e9f8-9a89-ecd8-b9e3-23dd6785ca64","name":"Page 11"},{"id":"78cd44b6-6a1c-daa1-f57c-c2838a792afc","name":"Page 12"},{"id":"e9f6c99d-0fce-68d9-ca44-b5b2cc91cfbd","name":"Page 13"},{"id":"61a00d2b-2d6e-d7a1-a774-fce670a8ef37","name":"Page 14"},{"id":"285ef568-8394-206f-0ab3-6ccc2627fdba","name":"Page 15"}]}],
        downloadLink: "//services.ninjamock.com/html/htmlExport/download?shareCode=DKZ3T&projectName=Untitled project",
        startupPageId: 0,

        forEachPage: function(func, thisArg){
        	for (var i = 0, l = this.pageGroups.length; i < l; ++i){
                var group = this.pageGroups[i];
                for (var j = 0, k = group.pages.length; j < k; ++j){
                    var page = group.pages[j];
                    if (func.call(thisArg, page) === false){
                    	return;
                    }
                }
            }
        },
        findPageById: function(pageId){
        	var result;
        	this.forEachPage(function(page){
        		if (page.id === pageId){
        			result = page;
        			return false;
        		}
        	});
        	return result;
        }
    }
});
